/*
 * Copyright 2013 - 2020, Siegfried Lohberg
 *
 * "THE BEER-WARE LICENSE" (Revision 42):
 * Siegfried Lohberg wrote this file. As long as you retain this notice you
 * can do whatever you want with this stuff. If we meet some day, and you think
 * this stuff is worth it, you can buy me a beer in return.
 */

/*
 * GPIO Usage
 */
#define DATA_PIN	RPI_V2_GPIO_P1_11
#define CLOCK_PIN	RPI_V2_GPIO_P1_15
#define LOAD_PIN	RPI_V2_GPIO_P1_16
#define RESET_PIN	RPI_V2_GPIO_P1_18

