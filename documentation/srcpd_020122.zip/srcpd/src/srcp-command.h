/* cvs: $Id: clientservice.h 899 2007-11-25 11:57:28Z gscholz $             */

/* 
 * Vorliegende Software unterliegt der General Public License, 
 * Version 2, 1991. (c) Matthias Trute, 2000-2001.
 *
 */

#ifndef _SRCP_COMMAND_H
#define _SRCP_COMMAND_H

#include "clientservice.h"

int doCmdClient(session_node_t*);

#endif
