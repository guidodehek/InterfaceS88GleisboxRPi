/* $Id: srcp-lock.c 681 2006-06-29 17:46:52Z gscholz $ */

/* 
 * Vorliegende Software unterliegt der General Public License, 
 * Version 2, 1991. (c) Matthias Trute, 2000-2001.
 *
 */
#include "srcp-lock.h"


int startup_LOCK(void)
{
    return 0;
}
