/* $Id: srcp-gm.h 990 2007-12-18 20:18:43Z gscholz $ */

/*
 *
 */


#ifndef _SRCP_GM_H
#define _SRCP_GM_H

int setGM(sessionid_t, sessionid_t, char *);

#endif
