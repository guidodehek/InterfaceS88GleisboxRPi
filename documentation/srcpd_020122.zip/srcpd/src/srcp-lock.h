/* $Id: srcp-lock.h 180 2002-05-04 19:22:05Z mtrute $ */

/* 
 * Vorliegende Software unterliegt der General Public License, 
 * Version 2, 1991. (c) Matthias Trute, 2000-2001.
 *
 */


#ifndef _SRCP_LOCK_H
#define _SRCP_LOCK_H

int startup_LOCK(void);

#endif
