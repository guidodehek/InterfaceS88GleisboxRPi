
#ifndef TOOLBOX_H
#define TOOLBOX_H

#include <sys/time.h>
#include "config.h"


/* compare time stamps */
int cmpTime(struct timeval *t1, struct timeval *t2);

#endif
